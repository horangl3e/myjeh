using UnityEngine;
using System.Collections;

public class EntityInfo 
{
	private int m_iHP;
	private int m_iMP;
	
	
	public void SetHP( int iHP )
	{
		m_iHP = iHP;
	}
	
	public int getHP
	{
		get
		{
			return m_iHP;
		}
	}
	
	
	
}
