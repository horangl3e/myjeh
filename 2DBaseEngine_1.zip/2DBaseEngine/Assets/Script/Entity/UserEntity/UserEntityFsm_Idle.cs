using UnityEngine;
using System.Collections;

public class UserEntityFsm_Idle : FsmState<UserEntity>
{
	float m_fTime = 0.0f;
	
	
	public UserEntityFsm_Idle( eFSM_STATE _fsmState, UserEntity _entity ) : base( _fsmState, _entity )
	{
		
	}
	
	
	public override void BeginState()
	{
		ownerEntity.SetMsg( new Msg_AnimationPlay("idle") );
	}
	public override void UpdateState()
	{
		
		m_fTime += Time.deltaTime;
		
		if( m_fTime < 0.2f ) 
			return;
		
		m_fTime = 0.0f;
		
		GameObject go = ResourceComm.CreateGameObject( "Entity/Missile/missile" );
		if( null == go )
		{
			Debug.LogError("load failed ( Entity/Missile/missile)");
			return;
		}
		Missile mi = go.GetComponent<Missile>();
		if( null == mi )
		{
			Debug.LogError(" no hava missile ");
			return;
		}
		
		mi.transform.position = new Vector3( ownerEntity.getPosition.x - 100.0f, ownerEntity.getPosition.y , ownerEntity.getPosition.z );
		mi.moveDirection = new Vector3( -3.0f, 0.0f, 0.0f );
		
	}
	public override void EndState()
	{
	}
}
