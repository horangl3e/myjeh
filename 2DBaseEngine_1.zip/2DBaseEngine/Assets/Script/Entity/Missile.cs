using UnityEngine;
using System.Collections;

public class Missile : MonoBehaviour 
{
	public eENTITY_TYPE owner;
	public int power = 1;
	public Vector3 moveDirection = Vector3.zero;
	

	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		transform.position = transform.position += moveDirection;
		
		if( transform.position.x < 0.0f )
			Destroy( gameObject );
	}
	
	
	void OnTriggerEnter(Collider other) 
	{		
		Entity _entity = EntityMgr.Instance.GetEntity( other.gameObject.GetInstanceID() );
		if( null == _entity )	
			return;
		
		switch( owner )
		{
		case eENTITY_TYPE.USER:
			if( eENTITY_TYPE.MONSTER == _entity.entityType )
			{
				_entity.getEntityInfo.SetHP( _entity.getEntityInfo.getHP - power );
				
				if( 0 >= _entity.getEntityInfo.getHP )
				{
					EntityMgr.Instance.DestoryEntity( _entity );
				}
				Destroy( gameObject);
			}
			break;
		}
		
	}
}
