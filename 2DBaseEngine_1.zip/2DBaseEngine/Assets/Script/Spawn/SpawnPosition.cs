using UnityEngine;
using System.Collections;

public class SpawnPosition : MonoBehaviour 
{
	
	private MonsterEntity m_mobEntity;
	
	public bool CreateMonster()
	{
		cSC_MONSTER_APPEAR_DATA _mobData = new cSC_MONSTER_APPEAR_DATA();
		_mobData.nIdx = 2;
		_mobData.nTableIdx = 2;
		_mobData.sCurPosition = transform.position;
		_mobData.fCurRotate = 0.0f;	
		_mobData.sCurSize = new Vector3( 1.0f, 1.0f, 1.0f );
		_mobData.fMoveSpeed = 50.0f;
		_mobData.iHP = 20;
		
		m_mobEntity = EntityMgr.Instance.CreateMonsterEntity( _mobData );
		m_mobEntity.SetMsg( new Msg_TargetMove( new Vector3( 1000.0f, transform.position.y, transform.position.z ) ) );
		
		return true;
	}
	
	public bool isExistMobEntity
	{
		get
		{
			return null != m_mobEntity;
		}
	}
	
	public MonsterEntity getMobEntity
	{
		get
		{
			return m_mobEntity;
		}
	}

	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{
	
	}
}
