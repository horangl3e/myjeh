using UnityEngine;
using System.Collections;

public class CameraMgr : MonoBehaviour 
{
	
	static CameraMgr m_instance;
	
	public static CameraMgr Instance
	{
		get
		{
			return m_instance;
		}
	}
	
	private Transform m_charTransform;
	private Vector3 m_vec3ViewTarget;
	private Vector3 m_vec3CameraPos;
	private Vector3 m_vec3InitDirection = Vector3.zero;
	public float zoom = 0.0f;
	
	
	public void AttachCameraToChar( Transform trm, Vector3 vec3VeiwTarget, Vector3 vec3CameraPos, float fFov )
	{
		m_charTransform = trm;
		m_vec3ViewTarget = vec3VeiwTarget;
		m_vec3CameraPos = vec3CameraPos;
		
		Vector3 vec3Temp = vec3VeiwTarget - m_vec3CameraPos;
		m_vec3InitDirection = vec3Temp.normalized;
		
		
		Camera.main.fov = fFov;	
		ResetCameraPos();
	}
	
	
	public void ResetCameraPos()
	{
		if( null == m_charTransform )
			return;
		
		Vector3 vec3Temp = m_charTransform.position + m_vec3ViewTarget + m_vec3CameraPos;
		Vector3 Vec3Direction = m_vec3InitDirection * zoom;		
		
		Camera.main.transform.position = vec3Temp + Vec3Direction;
		
		Vector3 relativePos = (m_charTransform.position + m_vec3ViewTarget) - transform.position;
        Quaternion rotation = Quaternion.LookRotation(relativePos);
        Camera.main.transform.rotation = rotation;
	}
	
	
	void Awake()
	{
		DontDestroyOnLoad(this);	
		m_instance = this;
	}

	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		ResetCameraPos();
	}
}
