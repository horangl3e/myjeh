using UnityEngine;
using System.Collections;

public class UISlot : MonoBehaviour 
{
	public UISprite img;
	
	
	public bool IsRect( Ray _ray )
	{
		if( null == collider )
			return false;
		
		return collider.bounds.IntersectRay( _ray );		
	}
	
	
	public void OnClick()
	{
		if( EntityMgr.Instance.getPlayerEntity )
		{
			EntityMgr.Instance.getPlayerEntity.SetMsg( new Msg_MoveStop() );
			EntityMgr.Instance.getPlayerEntity.SetState( eFSM_STATE.ATTACK );	
		}
	}
	
	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{
	
	}
	
	
}
