﻿using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Inventory System Tools
/// </summary>

public static class InvTools
{
	
}