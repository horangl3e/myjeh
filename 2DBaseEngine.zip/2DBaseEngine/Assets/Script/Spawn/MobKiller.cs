using UnityEngine;
using System.Collections;

public class MobKiller : MonoBehaviour 
{
	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{
	
	}
	
  	void OnCollisionEnter(Collision collision) 
	{
		Entity entity = EntityMgr.Instance.GetEntity( collision.gameObject.GetInstanceID() );
		if( null == entity )
			return;		
		
		EntityMgr.Instance.DestoryEntity( entity );
	}	
}
