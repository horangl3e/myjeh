using UnityEngine;
using System.Collections;

public class SpawnMgr : MonoBehaviour 
{
	
	public SpawnPosition[] spawnPositions;
	public MobKiller mobKiller;
	
	private static SpawnMgr ms_Instance = null;

    public static SpawnMgr Instance
    {
        get
        {
            return ms_Instance;
        }
    }
	
	void Awake()
	{
		ms_Instance = this;
		DontDestroyOnLoad(gameObject);					
	}
	
	
	
	
	
	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		foreach( SpawnPosition spawnpos in spawnPositions )
		{
			if( false == spawnpos.isExistMobEntity )
			{
				spawnpos.CreateMonster();
				continue;
			}
			
			if( spawnpos.getMobEntity.getPosition.x > 300.0f )
			{
				spawnpos.CreateMonster();
			}
		}
	}
}
