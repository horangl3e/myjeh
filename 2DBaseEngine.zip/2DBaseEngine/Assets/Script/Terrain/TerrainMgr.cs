using UnityEngine;
using System.Collections;

public class TerrainMgr : MonoBehaviour 
{
	public K2DSpriteUVMove map;
	

	static TerrainMgr m_instance;
	
	public static TerrainMgr Instance
	{
		get
		{
			return m_instance;
		}
	}
	
	void Awake()
	{
		DontDestroyOnLoad(this);	
		m_instance = this;
	}
	
	
	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		
	}
	
	public void Open()
	{
		map.gameObject.active = true;
	}
	
	public void Close()
	{
		map.gameObject.active = false;
	}
	
	private bool SetMaterial( string strPath )
	{
		Texture tex = ResourceComm.GetTexture( strPath );
		if( null == tex )
		{
			Debug.LogError("TerrainMgr::SetMaterial()[ null == texture ] path : " + strPath );
			return false;
		}
		
		map.spriteMaterial.mainTexture = tex;
		
		return true;
	}
	
	
	
	
	
	public static float GetTerrainHeight(CharacterController characterController, Vector3 _pos)
	{
		if( null == characterController )
		{
			Debug.LogError("TerrainMgr::GetTerrainHeight() [ null == characterController ]");
			return 0.0f;
		}
		Vector3 vec3Temp = _pos;
		vec3Temp.y = 100.0f;
		
		Ray ray = new Ray( vec3Temp, Vector3.down );
		RaycastHit hit;
		
		if(Physics.Raycast(ray, out hit, 10000f, 1<<LayerMask.NameToLayer("Terrain")) == true)
		{					
			float fCharCtlerHeight = 0.0f;
			float fCenter = -characterController.center.y;		
			
			if( characterController.height > (characterController.radius+characterController.radius) )
			{
				fCharCtlerHeight = fCenter + (characterController.height/2.0f);
			}
			else
			{
				fCharCtlerHeight = fCenter + characterController.radius;
			}
			
			fCharCtlerHeight *= characterController.transform.localScale.y; 
			float fHeight = fCharCtlerHeight +  hit.point.y + 0.02f;		
			return fHeight;	
		}	
		
		Debug.LogError("Physics.Raycast failed [ characterController ] ");
		
		return 0.0f;
	}
}
