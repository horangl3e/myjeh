using UnityEngine;
using System.Collections;

public class IntroScene : SceneBase 
{	
	private float m_fTime = 0.0f;
	private float m_fMaxTime = 0.0f;
	
	public IntroScene()
		:base(SceneBase.eSCENE_STATE.INTRO)
	{
	}
	
	public override void BeginState()
	{
	}
	
	public override void UpdateState()
	{
		m_fTime += Time.deltaTime;
		if( m_fMaxTime <= m_fTime )
		{
			SceneMgr.Instance.SetState( SceneBase.eSCENE_STATE.MAIN );
		}
	}
	
	public override void EndState()
	{
	}
	
	public override void InputUpdate( InputMgr.eINPUT_EVENT eInputEvent, Ray ray )
	{			
	}
	
	public override void GuiInputUpdata( InputMgr.eINPUT_EVENT eInputEvent, Ray ray )
	{				
	}	
}
