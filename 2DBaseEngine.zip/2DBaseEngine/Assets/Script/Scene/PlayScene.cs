using UnityEngine;
using System.Collections;

public class PlayScene : SceneBase 
{
	UserEntity m_player;	
	Ray m_DownClickRay;

	public PlayScene()
		:base(SceneBase.eSCENE_STATE.PLAY)
	{
	}
	
	public override void BeginState()
	{
		SceneMgr.Instance.BackgroundLoad("Play");
	}
	
	public override void UpdateState()
	{		
		
	}
	
	public override void EndState()
	{
		
	}
	
	public override void InputUpdate( InputMgr.eINPUT_EVENT eInputEvent, Ray ray )
	{			
		UIDlgMgr.Instance.InputUpdate( eInputEvent, ray );
		
		if( InputMgr.eINPUT_EVENT.DOWN == eInputEvent )
		{
			m_DownClickRay = ray;
		}
		else if( InputMgr.eINPUT_EVENT.MOVE == eInputEvent )
		{
			float difY = ray.origin.y - m_DownClickRay.origin.y; 
			
			Vector3 temp = m_player.getPosition;
			temp.y += difY;
			
			
			float fCharHeight = 100.0f;
			if( temp.y - fCharHeight < 0f )
			{
				temp.y = fCharHeight;
			}
			
			if( temp.y + fCharHeight > K2DView.defCameraPixels )
			{
				temp.y = K2DView.defCameraPixels - fCharHeight;
			}
			
			m_player.SetMsg( new Msg_TargetMove( temp ) );
			
			m_DownClickRay = ray;
		}
	}
	
	public override void GuiInputUpdata( InputMgr.eINPUT_EVENT eInputEvent, Ray ray )
	{			
		UIDlgMgr.Instance.GuiInputUpdata( eInputEvent, ray );
	}	
	
	
	public override void BackgroundLoad()
	{		
		cSC_USER_APPEAR_DATA _data = new cSC_USER_APPEAR_DATA();
		_data.nIdx = 1;
		_data.nTableIdx = 1;
		_data.sCurPosition = new Vector3( 860.0f, 320.0f, 0.0f );
		_data.fCurRotate = 0.0f;	
		_data.sCurSize = new Vector3( 1.0f, 1.0f, 1.0f );
		_data.fMoveSpeed = 10000.0f;		
		m_player = EntityMgr.Instance.CreatePlayerEntity( _data );			
	}
}
