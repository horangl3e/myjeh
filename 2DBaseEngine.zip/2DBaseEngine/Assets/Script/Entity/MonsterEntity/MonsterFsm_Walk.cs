using UnityEngine;
using System.Collections;

public class MonsterFsm_Walk : FsmState<MonsterEntity>
{
	
	public MonsterFsm_Walk( eFSM_STATE _fsmState, MonsterEntity _entity ) : base( _fsmState, _entity )
	{
		
	}	
	
	public override void BeginState()
	{
		ownerEntity.SetMsg( new Msg_AnimationPlay("walk") );
	}
	public override void UpdateState()
	{
		if( null == EntityMgr.Instance.getPlayerEntity )	
		{
			ownerEntity.SetState( eFSM_STATE.IDEL );
		}
		else
		{
			Vector3 tempDirection = EntityMgr.Instance.getPlayerEntity.getPosition - ownerEntity.getPosition;
			
			Vector3 tempgap = tempDirection.normalized * 0.5f;
			
			if( tempDirection.magnitude < tempgap.magnitude )
			{
				ownerEntity.SetMsg( new Msg_MoveStop() );
				ownerEntity.SetState( eFSM_STATE.ATTACK );	
			}
			else
			{							
				ownerEntity.SetMsg( new Msg_TargetMove( EntityMgr.Instance.getPlayerEntity.getPosition ) );
			}
		}
	}
	public override void EndState()
	{
		
	}
	
	public override void SetMsg( EntityMsg _msg )
	{
		switch( _msg.msg )
		{		
		case EntityMsg.eMSG.MOVE_RESULT_STOP:
			ownerEntity.SetState(eFSM_STATE.IDEL);
			break;
		}		
	}
	
}
