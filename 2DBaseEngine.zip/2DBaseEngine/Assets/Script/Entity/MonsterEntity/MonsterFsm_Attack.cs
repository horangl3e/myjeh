using UnityEngine;
using System.Collections;

public class MonsterFsm_Attack : FsmState<MonsterEntity>
{
	public MonsterFsm_Attack( eFSM_STATE _fsmState, MonsterEntity _entity ) : base( _fsmState, _entity )
	{
		
	}
	
	
	public override void BeginState()
	{		
		ownerEntity.SetMsg( new Msg_AnimationPlay("attack") );  
	}
	public override void UpdateState()
	{
		if( null == EntityMgr.Instance.getPlayerEntity )	
		{
			ownerEntity.SetState( eFSM_STATE.IDEL );
		}
		else
		{
			Vector3 tempDirection = EntityMgr.Instance.getPlayerEntity.getPosition - ownerEntity.getPosition;
			
			Vector3 tempgap = tempDirection.normalized * 1.0f;
			
			if( tempDirection.magnitude < tempgap.magnitude )
			{
				ownerEntity.SetMsg( new Msg_AnimationPlay("attack") ); 	
			}
			else
			{		
				ownerEntity.SetState(eFSM_STATE.WALK);				
			}
		}
		
		
	}
	public override void EndState()
	{
	}
	
	public override void SetMsg( EntityMsg _msg )
	{
		switch( _msg.msg )
		{		
		case EntityMsg.eMSG.ANIMATION_RESULT_STOP:
			Msg_AnimationResultStop stop = _msg as Msg_AnimationResultStop;
			if( stop.strAniName == "attack" )
			{			
				Vector3 pos = EntityMgr.Instance.getPlayerEntity.getPosition;
				
				if( (pos - ownerEntity.getPosition).magnitude < 0.8f )
				{
					
				}
			}
			break;
		}
	}
}
