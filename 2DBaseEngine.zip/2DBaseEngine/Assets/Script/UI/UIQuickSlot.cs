using UnityEngine;
using System.Collections;

public class UIQuickSlot : MonoBehaviour 
{
	public UISlot[] slots;
	
	private UISlot m_DownClickSlot = null;
	
	
	
	public void Open()
	{
	}
	
	public void Close()
	{
		
	}
	
	public void InputUpdate( InputMgr.eINPUT_EVENT eInputEvent, Ray ray )
	{
		
	}
	
	
	public void GuiInputUpdata( InputMgr.eINPUT_EVENT eInputEvent, Ray ray )
	{
		switch( eInputEvent )
		{
		case InputMgr.eINPUT_EVENT.DOWN:
			m_DownClickSlot = null;
			foreach( UISlot _slot in slots )
			{
				if( true == _slot.IsRect( ray ) )
				{
					m_DownClickSlot = _slot;
					return;
				}
			}			
			break;
			
		case InputMgr.eINPUT_EVENT.MOVE:
			break;
			
		case InputMgr.eINPUT_EVENT.UP:
			if( null != m_DownClickSlot && true == m_DownClickSlot.IsRect( ray ) )
			{
				m_DownClickSlot.OnClick();
			}
			break;
		}
		
		
		 
	}
		
	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
		{
	
	}
	
	
}
