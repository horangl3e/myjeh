using UnityEngine;
using System.Collections;

public class UIDlgMgr : MonoBehaviour 
{
	
	static UIDlgMgr m_instance;
	
	public static UIDlgMgr Instance
	{
		get
		{
			return m_instance;
		}
	}
	
	
	
	
	public UIQuickSlot quickSlot;
	public Joystick joystick;
	
	
	// quick
	public void OpenQuickSlot()
	{
		quickSlot.gameObject.SetActiveRecursively( true ); 
		quickSlot.Open();
	}
	
	public void CloseQuickSlot()
	{
		quickSlot.Close();
		quickSlot.gameObject.SetActiveRecursively( false );		
	}
	
	public bool IsOpenQuickSlot
	{
		get
		{
			if( null == quickSlot )
				return false;
			
			return quickSlot.gameObject.active;
		}
	}
	
	// Joystick
	public void OpenJoystick()
	{
		joystick.gameObject.SetActiveRecursively( true ); 
		joystick.Open();
	}
	
	public void CloseJoystick()
	{
		joystick.Close();
		joystick.gameObject.SetActiveRecursively( false );		
	}
	
	public bool IsOpenJoystick
	{
		get
		{
			if( null == joystick )
				return false;
			
			return joystick.gameObject.active;
		}
	}
	
	public void InputUpdate( InputMgr.eINPUT_EVENT eInputEvent, Ray ray )
	{
		if( IsOpenJoystick )
			joystick.InputUpdate( eInputEvent, ray );
		if( IsOpenQuickSlot )
			quickSlot.InputUpdate( eInputEvent, ray );
	}
	
	
	public void GuiInputUpdata( InputMgr.eINPUT_EVENT eInputEvent, Ray ray )
	{
		if( IsOpenJoystick )
			joystick.GuiInputUpdata( eInputEvent, ray );
		
		if( IsOpenQuickSlot )
			quickSlot.GuiInputUpdata( eInputEvent, ray );
	}
	
	
	void Awake()
	{
		DontDestroyOnLoad(this);	
		m_instance = this;
	}
	

	// Use this for initialization
	void Start () 
	{
		//CloseQuickSlot();
	}
	
	// Update is called once per frame
	void Update () 
	{
	
	}
}
