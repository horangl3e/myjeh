using UnityEngine;
using System.Collections;

public class Joystick : MonoBehaviour 
{		
	public GameObject ImgBall;
	public GameObject posBall;
	
	
	private Vector2 m_vec3Direction = Vector3.zero;
	//private bool m_bMoving = false;
	
	public Vector2 getDirection
	{
		get
		{
			return m_vec3Direction;
		}
	}
	
	public void Open()
	{
	}
	
	public void Close()
	{
	}
	
	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{
	
	}
	
	private void ResetDirection()
	{
		ImgBall.transform.position = posBall.transform.position;
		m_vec3Direction = Vector3.zero;
	}
	
	public void InputUpdate( InputMgr.eINPUT_EVENT eInputEvent, Ray ray )
	{
		/*if( InputMgr.eINPUT_EVENT.DOWN == eInputEvent || InputMgr.eINPUT_EVENT.MOVE == eInputEvent )
		{
			ResetDirection();
		}*/
		if( InputMgr.eINPUT_EVENT.UP == eInputEvent )
		{
			ResetDirection();
		}
	}
	
	
	public void GuiInputUpdata( InputMgr.eINPUT_EVENT eInputEvent, Ray ray )
	{
		if( InputMgr.eINPUT_EVENT.DOWN == eInputEvent || InputMgr.eINPUT_EVENT.MOVE == eInputEvent )
		{
			if( collider.bounds.IntersectRay(ray))
			{
				//m_bMoving = true;
				Vector3 vec3Temp = ray.origin;			
				vec3Temp.z = ImgBall.transform.position.z;
				ImgBall.transform.position = vec3Temp;					
				Vector3 tempCenter = posBall.transform.position;			
				
				tempCenter.z = 0.0f;
				vec3Temp.z = 0.0f;				
				
				m_vec3Direction.x = vec3Temp.x - tempCenter.x;
				m_vec3Direction.y = vec3Temp.y - tempCenter.y;
				
				return;
			}	
			
		}
		ResetDirection();
		
	}
}
